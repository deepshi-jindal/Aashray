# Aashray2021
Web portal deployed during the time of pandemic to provide verified oxygen, beds and other resources to people in need.

## Follow the steps to run it on your local system
- clone the folder
- create a virtual environment
- install the requirements
- launch your server
- create your own superuser to access the db
